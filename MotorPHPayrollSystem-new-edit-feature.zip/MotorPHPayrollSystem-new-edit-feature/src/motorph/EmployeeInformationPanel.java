/*
 * Programmer: A1101 GROUP 4 | Armilla, A., Belga, E., Franco, C., Jardeliza, L., Lasic, J.
 * Date: June 2025
 * Project: MotorPH Payroll System
 */

package motorph;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;
import javax.swing.SwingUtilities;

public class EmployeeInformationPanel extends javax.swing.JPanel {

    /**
     * Creates new form EmployeeInformationPanel
     */
    private EmployeeDirectoryPanel directoryPanel;
    private int employeeIndex;
    private String selectedEmpNo = "";
    private EmployeeTimeRecord employeeTimeRecord;
    private EditInformation editForm;

    public EmployeeInformationPanel(EmployeeDirectoryPanel directoryPanel, int employeeIndex) {
       
        this(employeeIndex);
        this.directoryPanel = directoryPanel;
        
        populateDateRanges();
        
    }
    
    public EmployeeInformationPanel(int employeeIndex) {
         this();
         this.employeeIndex = employeeIndex;
         EmployeeModelFromFile model = new EmployeeModelFromFile();
         loadEmployeeDataToFields(this.employeeIndex, model);
         editForm = new EditInformation(this.employeeIndex);
    }
    
    public EmployeeInformationPanel() {
        initComponents();
    }
    
   
   
    public void loadAttendanceFromCSV(String filename, String empNo) {
        System.out.println("Load Attendance:" + empNo);

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            br.readLine(); // skip header

            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length < 6) {
                    continue;
                }

                String recordEmpNo = data[0].trim();
                if (!recordEmpNo.equals(empNo)) {
                    continue;
                }

                String date = formatDate(data[3].trim());
                String timeInStr = data[4].trim();
                String timeOutStr = data[5].trim();

                int timeIn = parseHour(timeInStr);
                int timeOut = parseHour(timeOutStr);
                int hoursWorked = timeOut - timeIn;

                if (employeeTimeRecord != null && hoursWorked > 0) {
                    employeeTimeRecord.addWorkHours(date, hoursWorked);
                    System.out.println("Parsed: " + empNo + " | " + date + " | " + timeIn + " to " + timeOut + " = " + hoursWorked);
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error reading attendance CSV: " + ex.getMessage());
        }
    }

    private int parseHour(String time) {
        try {
            String[] parts = time.split(":");
            int hour = Integer.parseInt(parts[0]);
            int minute = Integer.parseInt(parts[1]);
            return (minute >= 30) ? hour + 1 : hour; // round up if >= 30 min
        } catch (Exception e) {
            System.err.println("Failed to parse time: [" + time + "]");
            return 0;
        }
    }

    private String formatDate(String rawDate) {
        try {
            Date date = new SimpleDateFormat("MM/dd/yyyy").parse(rawDate);
            return new SimpleDateFormat("yyyy-MM-dd").format(date);
        } catch (ParseException e) {
            System.err.println("Invalid date format: " + rawDate);
            return rawDate;
        }
    }

    public void loadEmployeeDataToFields(int empIndex, EmployeeModelFromFile employeeModel) {

        Employee[] allEmployees = employeeModel.getEmployeeModelList();
        Employee emp = allEmployees[empIndex];

        selectedEmpNo = emp.getEmpNo();
        employeeTimeRecord = new EmployeeTimeRecord(emp);

        System.out.println("Selected Emp: " + selectedEmpNo);
        System.out.println("Load Employee Semi Monthly: " + employeeTimeRecord.getSemiMonthlyRate());

        loadAttendanceFromCSV("src/resources/attendance_record.csv", selectedEmpNo);

        empNumField.setText(emp.getEmpNo());
        nameField.setText(emp.getFirstName() + " " + emp.getLastName());
        birthdayField.setText(emp.getBirthday());
        addressField.setText(emp.getAddress());
        phoneNoField.setText(emp.getPhoneNo());
        sssField.setText(emp.getSssNo());
        philhealthField.setText(emp.getPhilHealthNo());
        pagIbigField.setText(emp.getPagibigNo());
        tinField.setText(emp.getTinNo());
        statusField.setText(emp.getStatus());
        positionField.setText(emp.getPosition());
        salaryField.setText(String.valueOf(emp.getBasicSalary()));
        riceField.setText(String.valueOf(emp.getRiceSubsidy()));
        phoneField.setText(String.valueOf(emp.getPhoneAllowance()));
        clothingField.setText(String.valueOf(emp.getClothingAllowance()));
        supervisorField.setText(emp.getSupervisor());
    }

    private void populateDateRanges() {
        String[] ranges = {
            "2024-06-01 to 2024-06-15", "2024-06-16 to 2024-06-30",
            "2024-07-01 to 2024-07-15", "2024-07-16 to 2024-07-31",
            "2024-08-01 to 2024-08-15", "2024-08-16 to 2024-08-31",
            "2024-09-01 to 2024-09-15", "2024-09-16 to 2024-09-30",
            "2024-10-01 to 2024-10-15", "2024-10-16 to 2024-10-31",
            "2024-11-01 to 2024-11-15", "2024-11-16 to 2024-11-30",
            "2024-12-01 to 2024-12-15", "2024-12-16 to 2024-12-31"
        };
        for (String range : ranges) {
            jcbDateRange.addItem(range);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jTabbedPane8 = new javax.swing.JTabbedPane();
        personalInformationTab7 = new javax.swing.JPanel();
        empNumLabel = new javax.swing.JLabel();
        empNumField = new javax.swing.JTextField();
        nameLabel = new javax.swing.JLabel();
        nameField = new javax.swing.JTextField();
        birthdayLabel = new javax.swing.JLabel();
        birthdayField = new javax.swing.JTextField();
        addressLabel = new javax.swing.JLabel();
        addressField = new javax.swing.JTextField();
        phoneNoLabel = new javax.swing.JLabel();
        phoneNoField = new javax.swing.JTextField();
        sssLabel = new javax.swing.JLabel();
        sssField = new javax.swing.JTextField();
        philHealthLabel = new javax.swing.JLabel();
        philhealthField = new javax.swing.JTextField();
        tinLabel = new javax.swing.JLabel();
        tinField = new javax.swing.JTextField();
        pagIbigLabel = new javax.swing.JLabel();
        pagIbigField = new javax.swing.JTextField();
        editBtn = new javax.swing.JButton();
        employmentInformationTab = new javax.swing.JPanel();
        statusLabel = new javax.swing.JLabel();
        statusField = new javax.swing.JTextField();
        positionLabel = new javax.swing.JLabel();
        positionField = new javax.swing.JTextField();
        supervisorLabel = new javax.swing.JLabel();
        supervisorField = new javax.swing.JTextField();
        salaryLabel = new javax.swing.JLabel();
        salaryField = new javax.swing.JTextField();
        riceLabel = new javax.swing.JLabel();
        riceField = new javax.swing.JTextField();
        phoneLabel = new javax.swing.JLabel();
        phoneField = new javax.swing.JTextField();
        clothingLabel = new javax.swing.JLabel();
        clothingField = new javax.swing.JTextField();
        editBtn2 = new javax.swing.JButton();
        hoursComputationTab = new javax.swing.JPanel();
        labelNetSalary = new javax.swing.JLabel();
        labelOutputNetSalary = new javax.swing.JLabel();
        labelPayCoverage = new javax.swing.JLabel();
        jcbDateRange = new javax.swing.JComboBox<>();
        btnCompute = new javax.swing.JButton();
        labelNetSalary1 = new javax.swing.JLabel();

        jLabel3.setText("jLabel3");

        setMaximumSize(new java.awt.Dimension(500, 500));
        setMinimumSize(new java.awt.Dimension(500, 500));
        setPreferredSize(new java.awt.Dimension(500, 500));

        jPanel1.setMinimumSize(new java.awt.Dimension(500, 500));
        jPanel1.setPreferredSize(new java.awt.Dimension(550, 550));
        jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, javax.swing.BoxLayout.LINE_AXIS));

        personalInformationTab7.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        empNumLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        empNumLabel.setText("Employee NO.");

        empNumField.setEditable(false);
        empNumField.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        empNumField.setToolTipText("");
        empNumField.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        empNumField.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        empNumField.setEnabled(false);
        empNumField.setFocusable(false);
        empNumField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                empNumFieldActionPerformed(evt);
            }
        });

        nameLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        nameLabel.setText("Name");

        nameField.setEditable(false);
        nameField.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        nameField.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        nameField.setEnabled(false);
        nameField.setFocusable(false);

        birthdayLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        birthdayLabel.setText("Birthday");

        birthdayField.setEditable(false);
        birthdayField.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        birthdayField.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        birthdayField.setEnabled(false);
        birthdayField.setFocusable(false);

        addressLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        addressLabel.setText("Address");

        addressField.setEditable(false);
        addressField.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        addressField.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        addressField.setEnabled(false);
        addressField.setFocusable(false);

        phoneNoLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        phoneNoLabel.setText("Phone NO.");

        phoneNoField.setEditable(false);
        phoneNoField.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        phoneNoField.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        phoneNoField.setEnabled(false);
        phoneNoField.setFocusable(false);

        sssLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        sssLabel.setText("SSS NO.");

        sssField.setEditable(false);
        sssField.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        sssField.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        sssField.setEnabled(false);
        sssField.setFocusable(false);
        sssField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sssFieldActionPerformed(evt);
            }
        });

        philHealthLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        philHealthLabel.setText("PhilHealth NO.");

        philhealthField.setEditable(false);
        philhealthField.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        philhealthField.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        philhealthField.setEnabled(false);
        philhealthField.setFocusable(false);
        philhealthField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                philhealthFieldActionPerformed(evt);
            }
        });

        tinLabel.setText("TIN NO.");

        tinField.setEditable(false);
        tinField.setToolTipText("");
        tinField.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        tinField.setEnabled(false);
        tinField.setFocusable(false);
        tinField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tinFieldActionPerformed(evt);
            }
        });

        pagIbigLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        pagIbigLabel.setText("Pag-IBIG NO.               ");

        pagIbigField.setEditable(false);
        pagIbigField.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        pagIbigField.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        pagIbigField.setEnabled(false);
        pagIbigField.setFocusable(false);

        editBtn.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        editBtn.setText("Edit");
        editBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout personalInformationTab7Layout = new javax.swing.GroupLayout(personalInformationTab7);
        personalInformationTab7.setLayout(personalInformationTab7Layout);
        personalInformationTab7Layout.setHorizontalGroup(
            personalInformationTab7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(personalInformationTab7Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(personalInformationTab7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(editBtn)
                    .addGroup(personalInformationTab7Layout.createSequentialGroup()
                        .addGroup(personalInformationTab7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nameLabel)
                            .addComponent(empNumLabel)
                            .addComponent(birthdayLabel)
                            .addComponent(addressLabel)
                            .addComponent(phoneNoLabel)
                            .addComponent(sssLabel)
                            .addComponent(philHealthLabel)
                            .addComponent(pagIbigLabel)
                            .addComponent(tinLabel))
                        .addGap(36, 36, 36)
                        .addGroup(personalInformationTab7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(empNumField, javax.swing.GroupLayout.DEFAULT_SIZE, 306, Short.MAX_VALUE)
                            .addComponent(nameField)
                            .addComponent(birthdayField)
                            .addComponent(addressField)
                            .addComponent(phoneNoField)
                            .addComponent(sssField)
                            .addComponent(philhealthField)
                            .addComponent(tinField)
                            .addComponent(pagIbigField))))
                .addGap(20, 20, 20))
        );
        personalInformationTab7Layout.setVerticalGroup(
            personalInformationTab7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(personalInformationTab7Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(personalInformationTab7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(empNumLabel)
                    .addComponent(empNumField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(personalInformationTab7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nameLabel)
                    .addComponent(nameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(personalInformationTab7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(birthdayField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(birthdayLabel))
                .addGap(5, 5, 5)
                .addGroup(personalInformationTab7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addressLabel)
                    .addComponent(addressField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(personalInformationTab7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(phoneNoLabel)
                    .addComponent(phoneNoField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(personalInformationTab7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sssLabel)
                    .addComponent(sssField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(personalInformationTab7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(philHealthLabel)
                    .addComponent(philhealthField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(personalInformationTab7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tinLabel)
                    .addComponent(tinField, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE))
                .addGap(5, 5, 5)
                .addGroup(personalInformationTab7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(pagIbigField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pagIbigLabel))
                .addGap(18, 18, 18)
                .addComponent(editBtn)
                .addContainerGap(149, Short.MAX_VALUE))
        );

        jTabbedPane8.addTab("Personal Information", personalInformationTab7);

        statusLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        statusLabel.setText("Status");

        statusField.setEditable(false);
        statusField.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        statusField.setToolTipText("");
        statusField.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        statusField.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        statusField.setEnabled(false);
        statusField.setFocusable(false);
        statusField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                statusFieldActionPerformed(evt);
            }
        });

        positionLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        positionLabel.setText("Position");

        positionField.setEditable(false);
        positionField.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        positionField.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        positionField.setEnabled(false);
        positionField.setFocusable(false);
        positionField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                positionFieldActionPerformed(evt);
            }
        });

        supervisorLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        supervisorLabel.setText("Supervisor");

        supervisorField.setEditable(false);
        supervisorField.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        supervisorField.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        supervisorField.setEnabled(false);
        supervisorField.setFocusable(false);

        salaryLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        salaryLabel.setText("Basic Salary");

        salaryField.setEditable(false);
        salaryField.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        salaryField.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        salaryField.setEnabled(false);
        salaryField.setFocusable(false);

        riceLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        riceLabel.setText("Rice Subsidy");

        riceField.setEditable(false);
        riceField.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        riceField.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        riceField.setEnabled(false);
        riceField.setFocusable(false);

        phoneLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        phoneLabel.setText("Phone Allowance");

        phoneField.setEditable(false);
        phoneField.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        phoneField.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        phoneField.setEnabled(false);
        phoneField.setFocusable(false);
        phoneField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phoneFieldActionPerformed(evt);
            }
        });

        clothingLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        clothingLabel.setText("Clothing Allowance");

        clothingField.setEditable(false);
        clothingField.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        clothingField.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        clothingField.setEnabled(false);
        clothingField.setFocusable(false);
        clothingField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clothingFieldActionPerformed(evt);
            }
        });

        editBtn2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        editBtn2.setText("Edit");
        editBtn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editBtn2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout employmentInformationTabLayout = new javax.swing.GroupLayout(employmentInformationTab);
        employmentInformationTab.setLayout(employmentInformationTabLayout);
        employmentInformationTabLayout.setHorizontalGroup(
            employmentInformationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(employmentInformationTabLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(employmentInformationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(editBtn2)
                    .addGroup(employmentInformationTabLayout.createSequentialGroup()
                        .addGroup(employmentInformationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(positionLabel)
                            .addComponent(statusLabel)
                            .addComponent(supervisorLabel)
                            .addComponent(salaryLabel)
                            .addComponent(riceLabel)
                            .addComponent(phoneLabel)
                            .addComponent(clothingLabel))
                        .addGap(48, 48, 48)
                        .addGroup(employmentInformationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(statusField, javax.swing.GroupLayout.DEFAULT_SIZE, 306, Short.MAX_VALUE)
                            .addComponent(positionField)
                            .addComponent(supervisorField)
                            .addComponent(salaryField)
                            .addComponent(riceField)
                            .addComponent(phoneField)
                            .addComponent(clothingField))))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        employmentInformationTabLayout.setVerticalGroup(
            employmentInformationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(employmentInformationTabLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(employmentInformationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(statusLabel)
                    .addComponent(statusField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(employmentInformationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(positionLabel)
                    .addComponent(positionField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(employmentInformationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(supervisorField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(supervisorLabel))
                .addGap(5, 5, 5)
                .addGroup(employmentInformationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(salaryLabel)
                    .addComponent(salaryField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(employmentInformationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(riceLabel)
                    .addComponent(riceField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(employmentInformationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(phoneLabel)
                    .addComponent(phoneField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(employmentInformationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(clothingLabel)
                    .addComponent(clothingField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(editBtn2)
                .addContainerGap())
        );

        jTabbedPane8.addTab("Employment Information", employmentInformationTab);

        labelNetSalary.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        labelNetSalary.setText("Net Salary");

        labelOutputNetSalary.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N

        labelPayCoverage.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        labelPayCoverage.setText("Pay Coverage");

        jcbDateRange.setFont(new java.awt.Font("Arial", 2, 12)); // NOI18N
        jcbDateRange.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Pay Period..." }));
        jcbDateRange.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcbDateRangeActionPerformed(evt);
            }
        });

        btnCompute.setBackground(new java.awt.Color(0, 51, 0));
        btnCompute.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnCompute.setForeground(new java.awt.Color(255, 255, 255));
        btnCompute.setText("Compute");
        btnCompute.setToolTipText("");
        btnCompute.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnComputeActionPerformed(evt);
            }
        });

        labelNetSalary1.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        labelNetSalary1.setText("Php");

        javax.swing.GroupLayout hoursComputationTabLayout = new javax.swing.GroupLayout(hoursComputationTab);
        hoursComputationTab.setLayout(hoursComputationTabLayout);
        hoursComputationTabLayout.setHorizontalGroup(
            hoursComputationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, hoursComputationTabLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(hoursComputationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(hoursComputationTabLayout.createSequentialGroup()
                        .addComponent(labelPayCoverage, javax.swing.GroupLayout.DEFAULT_SIZE, 97, Short.MAX_VALUE)
                        .addGap(27, 27, 27))
                    .addGroup(hoursComputationTabLayout.createSequentialGroup()
                        .addComponent(labelNetSalary)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(hoursComputationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(hoursComputationTabLayout.createSequentialGroup()
                        .addComponent(jcbDateRange, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCompute, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(hoursComputationTabLayout.createSequentialGroup()
                        .addComponent(labelNetSalary1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(labelOutputNetSalary, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 12, Short.MAX_VALUE))
        );
        hoursComputationTabLayout.setVerticalGroup(
            hoursComputationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(hoursComputationTabLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(hoursComputationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelPayCoverage)
                    .addComponent(jcbDateRange, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCompute))
                .addGap(50, 50, 50)
                .addGroup(hoursComputationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(hoursComputationTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(labelNetSalary, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(labelNetSalary1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(labelOutputNetSalary, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(328, Short.MAX_VALUE))
        );

        jTabbedPane8.addTab("Salary Computation", hoursComputationTab);

        jPanel1.add(jTabbedPane8);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 470, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        getAccessibleContext().setAccessibleName("");
        getAccessibleContext().setAccessibleDescription("");
    }// </editor-fold>//GEN-END:initComponents

    private void btnComputeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnComputeActionPerformed
        if (employeeTimeRecord != null) {
            String[] range = ((String) jcbDateRange.getSelectedItem()).split(" to ");
            int totalHours = employeeTimeRecord.getTotalHoursWorked(range[0], range[1]);

            if (totalHours <= 0) {
                labelOutputNetSalary.setText("0.00");
                return;
            }
            double hourlyRate = employeeTimeRecord.getHourlyRate();
            double salaryOnHours = totalHours * hourlyRate;

            double riceSubsidy = employeeTimeRecord.getRiceSubsidy();
            double phoneAllowance = employeeTimeRecord.getPhoneAllowance();
            double clothingAllowance = employeeTimeRecord.getClothingAllowance();

            System.out.println(riceSubsidy);

            double totalAllowances = riceSubsidy + phoneAllowance + clothingAllowance;
            double netSalary = salaryOnHours + totalAllowances;

            System.out.println("Net Salary: " + netSalary);
            labelOutputNetSalary.setText(String.format("%.2f", netSalary));
        } else {
            JOptionPane.showMessageDialog(this, "Employee data not loaded.");
        }
    }//GEN-LAST:event_btnComputeActionPerformed

    private void jcbDateRangeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbDateRangeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jcbDateRangeActionPerformed

    private void clothingFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clothingFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_clothingFieldActionPerformed

    private void phoneFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phoneFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phoneFieldActionPerformed

    private void positionFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_positionFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_positionFieldActionPerformed

    private void statusFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_statusFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_statusFieldActionPerformed

    private void editBtn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editBtn2ActionPerformed
    // TODO add your handling code here:
        editForm.setVisible(true);
    }//GEN-LAST:event_editBtn2ActionPerformed

    private void tinFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tinFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tinFieldActionPerformed

    private void philhealthFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_philhealthFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_philhealthFieldActionPerformed

    private void sssFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sssFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sssFieldActionPerformed

    private void empNumFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_empNumFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_empNumFieldActionPerformed

    private void editBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editBtnActionPerformed
        // TODO add your handling code here:
        editForm.setVisible(true);
    }//GEN-LAST:event_editBtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JTextField addressField;
    private javax.swing.JLabel addressLabel;
    public javax.swing.JTextField birthdayField;
    private javax.swing.JLabel birthdayLabel;
    private javax.swing.JButton btnCompute;
    public javax.swing.JTextField clothingField;
    private javax.swing.JLabel clothingLabel;
    private javax.swing.JButton editBtn;
    private javax.swing.JButton editBtn2;
    public javax.swing.JTextField empNumField;
    private javax.swing.JLabel empNumLabel;
    private javax.swing.JPanel employmentInformationTab;
    private javax.swing.JPanel hoursComputationTab;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTabbedPane jTabbedPane8;
    private javax.swing.JComboBox<String> jcbDateRange;
    private javax.swing.JLabel labelNetSalary;
    private javax.swing.JLabel labelNetSalary1;
    private javax.swing.JLabel labelOutputNetSalary;
    private javax.swing.JLabel labelPayCoverage;
    public javax.swing.JTextField nameField;
    private javax.swing.JLabel nameLabel;
    public javax.swing.JTextField pagIbigField;
    private javax.swing.JLabel pagIbigLabel;
    private javax.swing.JPanel personalInformationTab7;
    private javax.swing.JLabel philHealthLabel;
    public javax.swing.JTextField philhealthField;
    public javax.swing.JTextField phoneField;
    private javax.swing.JLabel phoneLabel;
    public javax.swing.JTextField phoneNoField;
    private javax.swing.JLabel phoneNoLabel;
    public javax.swing.JTextField positionField;
    private javax.swing.JLabel positionLabel;
    public javax.swing.JTextField riceField;
    private javax.swing.JLabel riceLabel;
    public javax.swing.JTextField salaryField;
    private javax.swing.JLabel salaryLabel;
    public javax.swing.JTextField sssField;
    private javax.swing.JLabel sssLabel;
    public javax.swing.JTextField statusField;
    private javax.swing.JLabel statusLabel;
    public javax.swing.JTextField supervisorField;
    private javax.swing.JLabel supervisorLabel;
    private javax.swing.JTextField tinField;
    private javax.swing.JLabel tinLabel;
    // End of variables declaration//GEN-END:variables
}
